import json

def handler(event, context):
    method = event.get("httpMethod", "GET")
    path = event.get("path", "/")

    if path == "/api/namespaces" and method == "GET":
        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"},
            "body": json.dumps({
                "namespaces": [
                    {"name": "team-alpha", "status": "active", "quota": "20 CPU / 40Gi"},
                    {"name": "team-beta", "status": "active", "quota": "10 CPU / 20Gi"}
                ]
            })
        }

    if path == "/api/health":
        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"status": "healthy", "service": "developer-portal"})
        }

    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"},
        "body": json.dumps({
            "message": "GitOps EKS Developer Portal",
            "endpoints": ["/api/namespaces", "/api/health"]
        })
    }
